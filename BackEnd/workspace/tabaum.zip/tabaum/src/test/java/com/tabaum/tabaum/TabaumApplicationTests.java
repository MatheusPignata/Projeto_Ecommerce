package com.tabaum.tabaum;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TabaumApplicationTests {

	@Test
	void contextLoads() {
	}

}
