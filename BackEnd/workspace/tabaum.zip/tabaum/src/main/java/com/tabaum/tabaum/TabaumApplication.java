package com.tabaum.tabaum;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TabaumApplication {

	public static void main(String[] args) {
		SpringApplication.run(TabaumApplication.class, args);
	}

}
